/* 
 * File:   keywords.h
 * Author: rubenriveroroca
 *
 * Created on 29 de julio de 2016, 9:52   //github
 */

#ifndef KEYWORDS_H
#define	KEYWORDS_H

#ifdef	__cplusplus
extern "C" {
#endif
    
    
#define si if
#define sino else
#define haz do
#define mientras while
#define fin }
#define inicio {



#ifdef	__cplusplus
}
#endif

#endif	/* KEYWORDS_H */

